import React from "react";

export default function CustomerCare(){
    return(
        <div>I am Customer Care</div>
    );
}